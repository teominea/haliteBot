import java.util.ArrayList;
import java.util.List;

public class MyBot {
    private static final int MAX_STRENGTH = 255;
    private static final int TRESHOLD = 5;

    private static Location getNeighbour(GameMap gameMap, Location location, Direction direction) {
        return gameMap.getLocation(location, direction);
    }

    public static void main(String[] args) throws java.io.IOException {

        final InitPackage iPackage = Networking.getInit();
        final int myID = iPackage.myID;
        final GameMap gameMap = iPackage.map;

        Networking.sendInit("MyJavaBot");

        while(true) {
            List<Move> moves = new ArrayList<Move>();
            Networking.updateFrame(gameMap);

            for (int y = 0; y < gameMap.height; y++) {
                for (int x = 0; x < gameMap.width; x++) {
                    final Location location = gameMap.getLocation(x, y);
                    final Site site = location.getSite();

                    if (site.owner == myID) {
                        Direction direction = Direction.STILL;
                        if (site.strength >= site.production * TRESHOLD) {
                            direction = getBestGreedyBorderDirections(gameMap, location, myID);
                            if (direction == Direction.STILL) {
                                direction = getBestConsideringStrengths(gameMap, x, y, myID);
                            }
                        }
                        moves.add(new Move(location, direction));
                    }
                }
            }
            Networking.sendFrame(moves);
        }
    }

    private static Direction getBestGreedyBorderDirections(GameMap gameMap, Location location, int myID) {
        double bestRatio = -1;
        Direction bestDirection = Direction.STILL;
        for (Direction direction : Direction.CARDINALS) {
            Location neighbour = getNeighbour(gameMap, location, direction);
            Site neighbourSite = neighbour.getSite();
            if (neighbourSite.owner != myID) {
                double ratio = (double) neighbourSite.production / (double) neighbourSite.strength;
                if (ratio > bestRatio) {
                    bestRatio = ratio;
                    bestDirection = direction;
                }
            }
        }
        return bestDirection;
    }

    private static Direction getBestConsideringStrengths (GameMap map, int x, int y, int myID) {
        int strengthToFillUp = 0;
        int myStrengthToFillUp = 0;
        int strengthToFillDown = 0;
        int myStrengthToFillDown = 0;
        int strengthToFillLeft = 0;
        int myStrengthToFillLeft = 0;
        int strengthToFillRight = 0;
        int myStrengthToFillRight = 0;

        int best = 0;
        boolean allCornersAreMine = true;

        for (Direction d : Direction.CARDINALS) {
            final Location neighbour = map.getLocation(x, y);
            final Site neighbourSite = neighbour.getSite();
            if (neighbourSite.owner != myID) {
                allCornersAreMine = false;
                if (neighbourSite.strength > best) {
                    best = neighbourSite.strength;
                }
            }
        }

        for (int i = x; i >= 0; i--) {
            final Location location = map.getLocation(i, y);
            final Site site = location.getSite();
            if (site.owner != myID) {
                strengthToFillLeft += site.strength;
            } else {
                myStrengthToFillLeft += site.strength;
            }
        }
        for (int i = x; i < map.width; i++) {
            final Location location = map.getLocation(i, y);
            final Site site = location.getSite();
            if (site.owner != myID) {
                strengthToFillRight += site.strength;
            } else {
                myStrengthToFillRight += site.strength;
            }
        }
        for (int i = y; i >= 0; i--) {
            final Location location = map.getLocation(x, i);
            final Site site = location.getSite();
            if (site.owner != myID) {
                strengthToFillUp += site.strength;
            } else {
                myStrengthToFillUp += site.strength;
            }
        }
        for (int i = y; i < map.height; i++) {
            final Location location = map.getLocation(x, i);
            final Site site = location.getSite();
            if (site.owner != myID) {
                strengthToFillDown += site.strength;
            } else {
                myStrengthToFillDown += site.strength;
            }
        }
        int maxUnfilledUp = strengthToFillUp - myStrengthToFillUp;
        int maxUnfilledDown = strengthToFillDown - myStrengthToFillDown;
        int maxUnfilledLeft = strengthToFillLeft - myStrengthToFillLeft;
        int maxUnfilledRight = strengthToFillRight - myStrengthToFillRight;
        if (maxUnfilledUp >= maxUnfilledDown && maxUnfilledUp >= maxUnfilledLeft && maxUnfilledUp >= maxUnfilledRight) {
            return Direction.NORTH;
        }
        if (maxUnfilledDown >= maxUnfilledUp && maxUnfilledDown >= maxUnfilledLeft && maxUnfilledDown >= maxUnfilledRight) {
            return Direction.SOUTH;
        }
        if (maxUnfilledLeft >= maxUnfilledUp && maxUnfilledLeft >= maxUnfilledDown && maxUnfilledLeft >= maxUnfilledRight) {
            return Direction.WEST;
        }
        return Direction.EAST;
    }

    private static boolean isBorderTile(GameMap gameMap, Location location, int myID) {
        for (Direction direction : Direction.CARDINALS) {
            Location neighbor = getNeighbour(gameMap, location, direction);
            if (neighbor.getSite().owner != myID) {
                return true;
            }
        }
        return false;
    }
}